<?php if (!empty($errors)): ?>
    <ul class="alert alert-warning">
        <?php foreach ($errors as $error): ?>
            <li><?= esc($error) ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
