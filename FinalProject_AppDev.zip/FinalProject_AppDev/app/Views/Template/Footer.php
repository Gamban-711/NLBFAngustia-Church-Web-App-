</div> <!-- Close main-wrapper -->

<footer class="container-fluid">
  <p>&copy; <?= date('Y'); ?> FinalProject_AppDev. All rights reserved.</p>
</footer>

</body>
</html>
