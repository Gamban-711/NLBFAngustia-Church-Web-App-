<div class="sidebar">
  <h2>
    <img src="<?= base_url('assets/nlbflogo.png'); ?>" class="sidebar-logo custom-logo" alt="Logo">
    <div class="text-container">
      <span class="title">NLBFii</span>
      <span class="subtitle">Admin Panel</span>
    </div>
  </h2>

  <ul class="nav-list">
    <li <?= (current_url() == base_url("/Dashboard") ? 'class="active"' : '') ?>>
      <a href="<?= base_url("/Dashboard"); ?>">
        <i class="fas fa-home"></i> DASHBOARD
      </a>
    </li>
    <li <?= (current_url() == base_url("/Manager/churchfund") ? 'class="active"' : '') ?>>
      <a href="<?= base_url("/Manager/churchfund"); ?>">
        <i class="fas fa-hand-holding-usd"></i> CHURCH FUNDS
      </a>
    </li>
    <li <?= (current_url() == base_url("/Events") ? 'class="active"' : '') ?>>
      <a href="<?= base_url("/Events"); ?>">
        <i class="fas fa-calendar-alt"></i> CHURCH EVENTS
      </a>
    </li>
    <li <?= (current_url() == base_url("/AnnivCon") ? 'class="active"' : '') ?>>
      <a href="<?= base_url("/AnnivCon"); ?>">
        <i class="fas fa-gift"></i> ANNIV CONTRIBUTIONS
      </a>
    </li>
    <li <?= (current_url() == base_url("/Expenses") ? 'class="active"' : '') ?>>
      <a href="<?= base_url("/Expenses"); ?>">
        <i class="fas fa-receipt"></i> CHURCH EXPENSES
      </a>
    </li>

<li class="logout">
  <a href="javascript:void(0);" onclick="confirmLogout()">
    <i class="fas fa-sign-out-alt"></i> LOG OUT
  </a>
</li>

<script>
  function confirmLogout() {
    if (confirm("Are you sure you want to log out?")) {
      window.location.replace("<?= base_url('admin/logout'); ?>");
    }
  }
</script>
  </ul>
</div>
