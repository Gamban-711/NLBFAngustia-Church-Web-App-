<?= view('Template/Header'); ?>
<?= view('Template/SideNav'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
  * {
    box-sizing: border-box;
  }

  .content-area {
    padding: clamp(22px, 3vw, 42px);
    margin-left: 300px;
    margin-top: 58px;
    min-height: calc(100vh - 90px);
    background:
      radial-gradient(circle at 8% 10%, rgba(120, 170, 255, 0.35) 0%, rgba(120, 170, 255, 0) 45%),
      radial-gradient(circle at 92% 15%, rgba(160, 130, 255, 0.28) 0%, rgba(160, 130, 255, 0) 45%),
      radial-gradient(circle at 50% 100%, rgba(90, 200, 220, 0.25) 0%, rgba(90, 200, 220, 0) 50%),
      linear-gradient(160deg, #eaf2fd 0%, #dfeaf9 50%, #e7effc 100%);
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  /* ---------- Alerts / validation errors ---------- */
  .content-area > *:first-child:empty,
  .content-area > *:nth-child(2):empty {
    display: none;
  }

  /* ---------- Page heading ---------- */
  .content-area h4 {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0;
  }

  .content-area h4::before {
    content: "\f19c";
    font-family: "Font Awesome 6 Free";
    font-weight: 900;
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #6a8dff, #8f6bff);
    color: #fff;
    font-size: 15px;
    box-shadow: 0 6px 16px rgba(106, 141, 255, 0.4);
    flex-shrink: 0;
  }

  .content-area h4 small {
    font-weight: 700;
    font-size: 20px;
    letter-spacing: 0.4px;
    color: #1f2937;
  }

  .content-area hr {
    border: none;
    height: 1px;
    background: linear-gradient(90deg, rgba(100, 130, 200, 0.35), rgba(100, 130, 200, 0));
    margin: 20px 0 26px 0;
  }

  /* ---------- Action buttons ---------- */
  .d-flex.mb-3 {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
    margin: 0 0 22px;
    padding-top: 8px;
  }

  .btn-primary,
  .btn-success,
  .btn-warning,
  .btn-danger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 18px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 14px;
    letter-spacing: 0.2px;
    border: none;
    text-decoration: none;
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.12);
    transition: transform 0.2s ease, box-shadow 0.2s ease, filter 0.2s ease;
  }

  .btn-primary {
    background: linear-gradient(135deg, #6a8dff, #8f6bff);
    color: #fff;
  }

  .btn-success {
    background: linear-gradient(135deg, #22c55e, #16a34a);
    color: #fff;
  }

  .btn-primary:hover,
  .btn-success:hover {
    transform: translateY(-2px);
    filter: brightness(1.05);
    box-shadow: 0 10px 22px rgba(0, 0, 0, 0.18);
    color: #fff;
  }

  /* ---------- Table card (glassmorphism) ---------- */
  .table-card-wrapper {
    background: rgba(255, 255, 255, 0.55);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    border: 1px solid rgba(255, 255, 255, 0.6);
    border-radius: 20px;
    box-shadow:
      0 8px 24px rgba(31, 45, 90, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.7);
    padding: 22px;
  }

  #myTable {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
  }

  #myTable thead.table-dark th {
    background: linear-gradient(135deg, #2b3550, #1f2937);
    color: #fff;
    font-weight: 600;
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: 0.4px;
    padding: 14px 12px;
    border: none;
  }

  #myTable thead.table-dark th:first-child {
    border-top-left-radius: 12px;
  }

  #myTable thead.table-dark th:last-child {
    border-top-right-radius: 12px;
  }

  #myTable tbody td {
    padding: 13px 12px;
    font-size: 14px;
    color: #334155;
    background: rgba(255, 255, 255, 0.7);
    border-bottom: 1px solid rgba(148, 163, 184, 0.2);
    vertical-align: middle;
  }

  #myTable tbody tr {
    transition: background 0.2s ease;
  }

  #myTable tbody tr:hover td {
    background: rgba(106, 141, 255, 0.08);
  }

  #myTable tbody td.text-center {
    text-align: center;
    color: #64748b;
    padding: 30px 0;
  }

  .btn-warning,
  .btn-danger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 12.5px;
    line-height: 1.2;
    border: none;
    text-decoration: none;
    cursor: pointer;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.12);
    transition: transform 0.15s ease, filter 0.2s ease;
  }

  .btn-warning {
    background: linear-gradient(135deg, #fbbf24, #f59e0b);
    color: #3b2900;
  }

  .btn-danger {
    background: linear-gradient(135deg, #f87171, #ef4444);
    color: #fff;
  }

  .btn-warning:hover,
  .btn-danger:hover {
    transform: translateY(-1px);
    filter: brightness(1.05);
  }

  .action-btn-group {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
  }

  .action-btn-group form {
    margin: 0;
    display: inline-block;
  }

  .btn-sm {
    margin: 0;
  }

  /* ---------- DataTables chrome ---------- */
  .dataTables_wrapper .dataTables_filter input,
  .dataTables_wrapper .dataTables_length select {
    border-radius: 8px;
    border: 1px solid rgba(148, 163, 184, 0.4);
    padding: 5px 10px;
    background: rgba(255, 255, 255, 0.8);
  }

  .dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background: linear-gradient(135deg, #6a8dff, #8f6bff) !important;
    border: none !important;
    color: #fff !important;
    border-radius: 8px;
  }

  .dataTables_wrapper .dataTables_paginate .paginate_button {
    border-radius: 8px !important;
  }

  @media (max-width: 900px) {
    .content-area {
      margin-left: 0;
      margin-top: 0;
      padding: 20px 16px 28px;
    }

    .d-flex.mb-3 {
      gap: 10px;
    }
  }
</style>

<div class="content-area"> <!-- 🔥 New container for content -->
  <?= session()->getFlashdata('error') ?>
  <?= \Config\Services::validation()->listErrors() ?>

  <h4><small>CHURCH FUNDS</small></h4>
  <hr>

  <div class="d-flex mb-3">
    <a class="btn btn-primary" href="<?= base_url("Manager/AddFund"); ?>" role="button">
      <span class="glyphicon glyphicon-plus"></span> Add Fund
    </a>

    <button type="button" class="btn btn-success report-modal-btn" data-report-url="<?= base_url('Manager/Reports/ChurchFundReport') ?>">
      <span class="glyphicon glyphicon-print"></span> Generate Report
    </button>
  </div>

  <div class="table-card-wrapper">
    <table id="myTable" class="display" style="width:100%">
      <thead class="table-dark">
        <tr>
          <th>Fund ID</th>
          <th>Fund Type</th>
          <th>Amount</th>
          <th>Description</th>
          <th>Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($FundInfo)): ?>
          <?php foreach ($FundInfo as $fund): ?>
            <tr>
              <td><?= esc($fund['fund_Id']) ?></td>
              <td><?= esc($fund['fund_type']) ?></td>
              <td>₱<?= number_format($fund['amount'], 2) ?></td>
              <td><?= esc($fund['description']) ?></td>
              <td><?= esc($fund['date']) ?></td>
              <td>
                <div class="action-btn-group">
                  <a href="<?= base_url('Manager/EditFund/' . $fund['fund_Id']) ?>" class="btn btn-warning btn-sm">
                    <span class="glyphicon glyphicon-edit"></span> Edit
                  </a>

                  <form action="<?= base_url('Manager/deleteFund/' . $fund['fund_Id']) ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this fund?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-danger btn-sm">
                      <span class="glyphicon glyphicon-trash"></span> Delete
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td></td>
            <td></td>
            <td class="text-center">No records found.</td>
            <td></td>
            <td></td>
            <td></td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="reportModal" tabindex="-1" role="dialog" aria-labelledby="reportModalLabel">
  <div class="modal-dialog modal-lg" role="document" style="width: 90%; max-width: 1200px;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="reportModalLabel">Church Fund Report</h4>
      </div>
      <div class="modal-body" style="padding: 0; background: #f2f2f2;">
        <iframe id="reportFrame" src="" style="width: 100%; height: 75vh; border: none;"></iframe>
      </div>
      <div class="modal-footer">
        <a id="downloadReportBtn" class="btn btn-primary" href="#" download>Download PDF</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).ready(function () {
    $('#myTable').DataTable({
      scrollCollapse: true,
      scrollX: true,
      scrollY: 300
    });

    $('.report-modal-btn').on('click', function () {
      const reportUrl = $(this).data('report-url');
      $('#reportFrame').attr('src', reportUrl);
      $('#downloadReportBtn').attr('href', reportUrl + '?download=1');
      $('#reportModal').modal('show');
    });
  });
</script>