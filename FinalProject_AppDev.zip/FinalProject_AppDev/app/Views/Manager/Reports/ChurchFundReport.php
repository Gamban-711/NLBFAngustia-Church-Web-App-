<!DOCTYPE html>
<html>
<head>
    <title>Church Fund Report</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 40px;
            background: #eef2f7;
            color: #1e293b;
        }

        .sheet {
            max-width: 850px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 14px;
            box-shadow: 0 10px 30px rgba(31, 45, 90, 0.12);
            padding: 40px 46px;
        }

        .header {
            text-align: center;
            margin-bottom: 10px;
            padding-bottom: 20px;
            border-bottom: 3px solid #6a8dff;
        }

        .header .badge {
            width: 60px;
            height: 60px;
            margin: 0 auto 12px auto;
            border-radius: 50%;
            background: linear-gradient(135deg, #6a8dff, #8f6bff);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            box-shadow: 0 6px 16px rgba(106, 141, 255, 0.35);
        }

        .header h3 {
            margin: 4px 0;
            font-size: 19px;
            font-weight: 700;
            color: #1e293b;
            letter-spacing: 0.2px;
        }

        .header h4 {
            margin: 2px 0 8px 0;
            font-size: 15px;
            font-weight: 600;
            color: #6a8dff;
            text-transform: uppercase;
            letter-spacing: 0.6px;
        }

        .header p {
            margin: 0;
            font-size: 13px;
            color: #64748b;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 28px;
            font-size: 13.5px;
        }

        th {
            background: linear-gradient(135deg, #2b3550, #1f2937);
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            font-size: 11.5px;
            padding: 10px 8px;
            border: 1px solid #1f2937;
        }

        th:first-child {
            border-top-left-radius: 8px;
        }

        th:last-child {
            border-top-right-radius: 8px;
        }

        td {
            border: 1px solid #e2e8f0;
            padding: 9px 8px;
            text-align: center;
            color: #334155;
        }

        tbody tr:nth-child(even) td {
            background: #f8fafc;
        }

        .total {
            font-weight: 700;
        }

        .total td {
            background: linear-gradient(135deg, rgba(106, 141, 255, 0.12), rgba(143, 107, 255, 0.12));
            color: #1e293b;
            border-top: 2px solid #6a8dff;
        }

        .footer {
            margin-top: 40px;
            font-size: 13px;
            text-align: right;
            color: #64748b;
            border-top: 1px solid #e2e8f0;
            padding-top: 14px;
        }

        .footer strong {
            color: #1e293b;
        }

        .actions {
            text-align: center;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 9px 20px;
            margin-top: 10px;
            background: linear-gradient(135deg, #22c55e, #16a34a);
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 6px 16px rgba(34, 197, 94, 0.3);
            transition: transform 0.2s ease, filter 0.2s ease;
        }

        .btn:hover {
            filter: brightness(1.05);
            transform: translateY(-2px);
        }

        @media print {
            body {
                background: #fff;
                padding: 0;
            }

            .sheet {
                box-shadow: none;
                border-radius: 0;
                padding: 0;
                max-width: 100%;
            }

            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="sheet">

    <div class="actions no-print">
        <button class="btn" onclick="window.print()">
            <span>&#128438;</span> Print / Save as PDF
        </button>
    </div>

    <div class="header" style="display: flex; align-items: center; justify-content: space-between; gap: 18px; text-align: left; border-bottom: 3px solid #6a8dff;">
        <?php if (!empty($logoPath)): ?>
            <img src="<?= $logoPath ?>" alt="NLBF Logo" style="width: 90px; height: 90px; object-fit: contain; border-radius: 14px; flex-shrink: 0; background: #f8fafc; padding: 8px; box-sizing: border-box;">
        <?php else: ?>
            <div class="badge" style="width: 90px; height: 90px; border-radius: 14px; background: linear-gradient(135deg, #6a8dff, #8f6bff); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 700; flex-shrink: 0;">NLBF</div>
        <?php endif; ?>

        <div style="flex: 1; min-width: 0;">
            <h3 style="margin: 0 0 4px 0; font-size: 19px; font-weight: 700; color: #1e293b;">New Life Believers Fellowship International Incorporated</h3>
            <h4 style="margin: 0 0 6px 0; font-size: 15px; font-weight: 600; color: #6a8dff; text-transform: uppercase; letter-spacing: 0.6px;">Church Fund Report</h4>
            <p style="margin: 0; font-size: 13px; color: #64748b;">Date: <?= date('F d, Y') ?></p>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Source</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php $grandTotal = 0; ?>

            <?php foreach ($FundInfo as $FundInfo): ?>
                <tr>
                    <td><?= esc($FundInfo['fund_Id']) ?></td>
                    <td><?= esc($FundInfo['fund_type']) ?></td>
                    <td>P<?= number_format($FundInfo['amount'], 2) ?></td>
                    <td><?= esc($FundInfo['date']) ?></td>
                    <td><?= esc($FundInfo['description']) ?></td>
                </tr>
                <?php $grandTotal += $FundInfo['amount']; ?>
            <?php endforeach; ?>
            <tr class="total">
                <td colspan="2">Grand Total</td>
                <td colspan="3">P<?= number_format($grandTotal, 2) ?></td>
            </tr>
        </tbody>
    </table>

    <div class="footer">
        Generated by: <strong><?= session()->get('username') ?? 'Admin' ?></strong><br>
        Printed on: <?= date('F d, Y h:i A') ?>
    </div>

</div>

</body>
</html>