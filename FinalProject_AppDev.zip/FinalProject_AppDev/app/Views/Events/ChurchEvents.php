<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Calendar with Events</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body {
  font-family: 'Segoe UI', sans-serif;
  margin: 0;
  padding: 0;
  background-color: #D7E7F8;
  color: #2F3B4C;
}

h1 {
  text-align: center;
  color: #5C8DCB;
  margin: 20px 0;
}

.container {
  display: flex;
  flex-direction: column;
  padding: 20px;
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  background: #eaf4fd;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

@media (min-width: 768px) {
  .content {
    flex-direction: row;
    height: auto;
  }
}

.sidebar, .calendar {
  flex: 1;
  background: #ffffff;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
  overflow: auto;
  max-height: 600px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  background-color: white;
  border-radius: 6px;
  overflow: hidden;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
}

th, td {
  border: 1px solid #a5bed8;
  padding: 10px;
  text-align: left;
  word-wrap: break-word;
  color: #2F3B4C;
}

th {
  background-color: #5C8DCB;
  color: #fff;
}

.calendar .header {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.days {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(90px, 1fr));
  gap: 10px;
}

.day {
  background-color: #e1eaf4;
  padding: 15px;
  border-radius: 6px;
  text-align: center;
  cursor: pointer;
  transition: background-color 0.3s;
}

.day:hover {
  background-color: #BCD7F5;
}

.day.isToday {
  background-color: #FFEB7F;
}

.event {
  background-color: #F0AD4E;
  color: white;
}

button, .btn {
  background-color: #5C8DCB;
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: bold;
  transition: background-color 0.3s;
  margin-right: 10px; /* Adds space between buttons */
}

button:hover, .btn:hover {
  background-color: #4a7bb6;
}

.back-button {
  background-color: #7DA9D9;
  margin-bottom: 15px;
}

.back-button:hover {
  background-color: #5C8DCB;
}

.btn i {
  pointer-events: none; /* Prevents double click */
}

.btn-warning i, .btn-danger i {
  font-size: 16px;
}

.btn-warning {
  background-color: #F0AD4E;
  color: white;
}

.btn-warning:hover {
  background-color: #ec9e2e;
}

.btn-danger {
  background-color: #D9534F;
  color: white;
}

.btn-danger:hover {
  background-color: #c9302c;
}

.form-popup {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #ffffff;
  padding: 20px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  z-index: 10;
  width: 90%;
  max-width: 500px;
}

.form-popup label,
input,
textarea {
  display: block;
  width: 100%;
  margin-top: 10px;
  font-weight: bold;
  color: #2F3B4C;
}

input, textarea {
  padding: 8px;
  border: 1px solid #a5bed8;
  border-radius: 6px;
  background-color: #fff;
}

textarea {
  resize: vertical;
  min-height: 80px;
}
</style>




</head>
<body>
  <h1>Add Events and Activities</h1>
  <div class="container">
    <a href="/Dashboard"><button class="back-button">Back to Dashboard</button></a>
    <div class="content">
      <div class="sidebar">
<!-- Updated Events Summary Table -->
<h3>Events Summary</h3>
<table id="myTable" class="display" style="width:100%">
  <thead class="table-dark">
    <tr>
      <th>Date</th>
      <th>Time</th>
      <th>Event Name</th>
      <th>Description</th> <!-- ✅ Added column -->
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php if (!empty($eventsByDate)): ?>
      <?php foreach ($eventsByDate as $date => $events): ?>
        <?php foreach ($events as $event): ?>
          <tr>
            <td><?= date('Y-m-d', strtotime($event['date'])) ?></td>
            <td><?= esc($event['time']) ?></td>
            <td><?= esc($event['event_name']) ?></td>
            <td><?= esc($event['description']) ?></td> <!-- ✅ Added description output -->
            <td>
            <a href="<?= base_url('Events/EditEvent/' . $event['event_Id']) ?>" class="btn btn-warning" title="Edit">
              <i class="fas fa-edit"></i>
            </a>
            <form action="<?= base_url('Events/deleteEvent/' . $event['event_Id']) ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this event?');">
              <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                <i class="fas fa-trash-alt"></i>
              </button>
            </form>
          </td>

          </tr>
        <?php endforeach; ?>
      <?php endforeach; ?>
    <?php else: ?>
      <tr>
        <td></td>
        <td></td>
        <td class="text-center">No events found.</td>
        <td></td>
        <td></td>
      </tr>
    <?php endif; ?>
  </tbody>
</table>



      </div>
      <div class="calendar">
        <div class="header">
          <button id="prev">Prev</button>
          <h2 class="month-title"></h2>
          <button id="next">Next</button>
        </div>
        <div class="days"></div>
      </div>
    </div>
  </div>

  <div class="form-popup" id="eventForm">
  <h3>Add Event</h3>
  <form action="<?= site_url('Events/insertEvent') ?>" method="post">
  <?= csrf_field() ?>

    <!-- Hidden field for event_Id, for editing an existing event -->
    <input type="hidden" id="event_Id" name="event_Id" value="<?= isset($event['event_Id']) ? $event['event_Id'] : '' ?>">

    <!-- ✅ Hidden field for selected date -->
    <input type="hidden" id="eventDate" name="date">

    <!-- Event details form -->
    <label>Date: <span id="selectedDate"></span></label>
    <label>Event Name: <input type="text" id="eventName" name="event_name" value="<?= isset($event['event_name']) ? $event['event_name'] : '' ?>" required /></label>
    <label>Time: <input type="time" id="eventTime" name="time" value="<?= isset($event['time']) ? $event['time'] : '' ?>" required /></label>
    <label>Description: <textarea id="eventDesc" name="description"><?= isset($event['description']) ? $event['description'] : '' ?></textarea></label>
    <button type="submit">Save Event</button>
    <button type="button" onclick="closeForm()">Cancel</button>
  </form>
</div>


  <script>
    const daysContainer = document.querySelector('.days');
    const monthTitle = document.querySelector('.month-title');
    let currentDate = new Date();
    const eventsByDate = <?php echo json_encode($eventsByDate); ?>;  // Pass PHP data to JavaScript

    function renderCalendar() {
      daysContainer.innerHTML = '';
      const firstDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const lastDay = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
      const today = new Date();

      monthTitle.textContent = firstDay.toLocaleDateString('en-us', { month: 'long', year: 'numeric' });

      for (let i = 0; i < firstDay.getDay(); i++) {
        const emptyDiv = document.createElement('div');
        emptyDiv.classList.add('day');
        daysContainer.appendChild(emptyDiv);
      }

      for (let day = 1; day <= lastDay.getDate(); day++) {
        const dayDiv = document.createElement('div');
        dayDiv.classList.add('day');
        dayDiv.textContent = day;

        const checkDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
        const formattedDate = checkDate.toISOString().split('T')[0]; // Format date as 'YYYY-MM-DD'
        
        // Highlight the current day
        if (checkDate.toDateString() === today.toDateString()) {
          dayDiv.classList.add('isToday');
        }

        // Add event markers
        if (eventsByDate[formattedDate]) {
          dayDiv.classList.add('event');
        }

        dayDiv.onclick = () => openForm(checkDate);
        daysContainer.appendChild(dayDiv);
      }
    }

    document.getElementById('prev').onclick = () => {
      currentDate.setMonth(currentDate.getMonth() - 1);
      renderCalendar();
    };

    document.getElementById('next').onclick = () => {
      currentDate.setMonth(currentDate.getMonth() + 1);
      renderCalendar();
    };

    function openForm(date) {
  const formatted = date.toISOString().split('T')[0]; // Format: YYYY-MM-DD
  document.getElementById('selectedDate').textContent = formatted;
  document.getElementById('eventDate').value = formatted; // ✅ set hidden input value
  document.getElementById('eventForm').style.display = 'block';
}

    function closeForm() {
      document.getElementById('eventForm').style.display = 'none';
    }

    renderCalendar();
  </script>
</body>
</html>
