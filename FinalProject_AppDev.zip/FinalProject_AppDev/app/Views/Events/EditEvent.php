<style>
    .edit-event-container {
        max-width: 600px;
        margin: 40px auto;
        padding: 30px;
        background-color: #eaf4fd; /* Matches theme background */
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.05);
        font-family: 'Segoe UI', sans-serif;
    }

    .edit-event-container h2 {
        text-align: center;
        color: #2F3B4C;
        margin-bottom: 25px;
        font-weight: 700;
    }

    .edit-event-container label {
        display: block;
        margin-top: 15px;
        color: #2F3B4C;
        font-weight: 600;
        font-size: 14px;
    }

    .edit-event-container input[type="text"],
    .edit-event-container input[type="date"],
    .edit-event-container input[type="time"],
    .edit-event-container textarea {
        width: 100%;
        padding: 10px 12px;
        margin-top: 6px;
        border: 1px solid #a5bed8;
        border-radius: 10px;
        box-sizing: border-box;
        font-size: 15px;
        background-color: #ffffff;
        color: #2F3B4C;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .edit-event-container input:focus,
    .edit-event-container textarea:focus {
        border-color: #7DA9D9;
        box-shadow: 0 0 5px rgba(125, 169, 217, 0.3);
        outline: none;
    }

    .edit-event-container textarea {
        resize: vertical;
        min-height: 100px;
    }

    .edit-event-container button {
        width: 100%;
        padding: 12px;
        background-color: #5C8DCB;
        border: none;
        color: white;
        font-size: 16px;
        font-weight: bold;
        border-radius: 10px;
        margin-top: 25px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .edit-event-container button:hover {
        background-color: #4a7bb6;
    }

    h4 small {
        display: block;
        margin: 30px auto 0;
        text-align: center;
        font-size: 18px;
        font-weight: 600;
        color: #2F3B4C;
    }

    hr {
        max-width: 600px;
        margin: 10px auto 30px;
        border-color: #a5bed8;
    }
</style>


<h4><small>EDIT CHURCH EVENTS</small></h4>
<hr>

<div class="edit-event-container">
    <h2>Edit Event</h2>

    <form action="<?= base_url('Events/updateEvent/' . $event['event_Id']) ?>" method="POST">
        <?= csrf_field() ?>

        <label for="event_name">Event Name:</label>
        <input type="text" name="event_name" id="event_name" value="<?= esc($event['event_name']) ?>" required>

        <label for="date">Date:</label>
        <input type="date" name="date" id="date" value="<?= esc($event['date']) ?>" required>

        <label for="time">Time:</label>
        <input type="time" name="time" id="time" value="<?= esc($event['time']) ?>" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" required><?= esc($event['description']) ?></textarea>

        <button type="submit">Update</button>
    </form>
</div>
